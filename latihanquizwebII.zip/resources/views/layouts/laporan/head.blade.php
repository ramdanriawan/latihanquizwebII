<?php date_default_timezone_set('Asia/Jakarta'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>
        Laporan Barang
    </title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href='{{ asset('css/style.css') }}' rel='stylesheet' />

    {{--  font awesome --}}
    <link rel="stylesheet" href="/node_modules/@fortawesome/fontawesome-free/css/all.min.css" />
    <script rel="stylesheet" href="/node_modules/@fortawesome/fontawesome-free/js/all.min.js"></script>

</head>
