<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>

                <div class="card-header">Data Pelanggan</div>

                <div class="card-body">
                   <table class="table table-bordered table-hover">
                       <thead>
                           <tr>
                               <th>No</th>
                               <th>Nama</th>
                               <th>Umur</th>
                               <th>Alamat</th>
                               <th>Gambar</th>
                               <th>Actions</th>
                           </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                               <td><?php echo e($pelanggan->nama); ?></td>
                               <td><?php echo e($pelanggan->umur); ?></td>
                               <td><?php echo e($pelanggan->alamat); ?></td>
                               <td><button
                                    class="btn btn-default btn-sm btn-gambar"
                                    data-toggle="modal"
                                    data-target="#gambarModal"
                                    data-local='#carousel-generic'
                                    data-link='<?php echo e($pelanggan->gambar); ?>'
                                    data-gambar-nama='<?php echo e($pelanggan->nama); ?>' >
                                       <i class="far fa-eye"></i> Show
                                   </button>
                               </td>
                                   <td>
                                    <span class="btn-group btn-group-sm">
                                        <button class="btn btn-primary btn-sm indexBtnEdit" data-id='<?php echo e($pelanggan->id); ?>' data-toggle='modal' data-target='#editModal<?php echo e($pelanggan->id); ?>'>
                                            <i class="far fa-edit"></i>
                                        </button>
                                        <form id="formDelete" action="/admin/pelanggan/<?php echo e($pelanggan->id); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="_method" value="DELETE">
                                        </form>
                                        <button form="formDelete" class="btn btn-danger btn-sm btn-delete" type="submit" data-nama="<?php echo e($pelanggan->id); ?>" data-token='<?php echo e(csrf_token()); ?>'> <i class="far fa-trash-alt"></i>
                                        </button>
                                    </span>

                               </td>
                           </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                   </table>
                </div>




            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<div class="modal fade" id="gambarModal" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
          <h4 class="modal-title">Gambar untuk <span id="dataGambarNama"></span></h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body">
          <div id="demo" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ul class="carousel-indicators">
              <li data-target="#demo" data-slide-to="0" class="active"></li>
              <li data-target="#demo" data-slide-to="1"></li>
              <li data-target="#demo" data-slide-to="2"></li>
            </ul>

            <!-- The slideshow -->
            <div class="carousel-inner" id='gambarItem'>
                
            </div>

            <!-- Left and right controls -->
            <a class="carousel-control-prev" href="#demo" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
              <span class="carousel-control-next-icon"></span>
            </a>

          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div id="editModal<?php echo e($pelanggan->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-body">
            <div class="card">
            <div class="card-header">Edit data</div>
                <div class="card-body">

                    <?php echo $__env->make('layouts.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('layouts.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <form action='/admin/pelanggan/<?php echo e($pelanggan->id); ?>' method='post' enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">

                        <div class="form-group">
                            <label for="nama">Nama*</label>
                            <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid': ''); ?>" type="text" name="nama" value="<?php echo e($pelanggan->nama); ?>" placeholder="nama" required>
                            <?php if($errors->has('nama')): ?>
                            <p class="text-danger"><?php echo e($errors->first('nama')); ?></p>
                            <?php endif; ?>
                        </div>


                        <div class="form-group">
                            <label for="nama">umur*</label>
                            <input class="form-control <?php echo e($errors->has('umur') ? 'is-invalid': ''); ?>" type="text" name="umur" value="<?php echo e($pelanggan->umur); ?>" placeholder="umur" required>
                            <?php if($errors->has('umur')): ?>
                            <p class="text-danger"><?php echo e($errors->first('umur')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="alamat">alamat*</label>
                            <input class="form-control <?php echo e($errors->has('alamat') ? 'is-invalid': ''); ?>" type="text" name="alamat" value="<?php echo e($pelanggan->alamat); ?>" placeholder="alamat" required>
                            <?php if($errors->has('alamat')): ?>
                            <p class="text-danger"><?php echo e($errors->first('alamat')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="gambar">Gambar (tandai beberapa sekaligus), max:5</label>
                            <input class="form-control  <?php echo e($errors->has('gambar') || $errors->has('gambar.*') ? 'is-invalid': ''); ?>" type="file" name="gambar[]" multiple>
                            <?php if($errors->has('gambar.*')): ?>
                            <p class="text-danger"><?php echo e($errors->first('gambar.*')); ?></p>
                            <p class="text-danger"><?php echo e($errors->first('gambar')); ?></p>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-sm">
                            Simpan data barang
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm"
                                onclick='
                                    if(!confirm("Apakah anda yakin akan mereset data ini?"))
                                    {
                                        return false;
                                    }
                                '
                        >
                            Reset
                        </button>
                    </form>
                </div>
            </div>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>