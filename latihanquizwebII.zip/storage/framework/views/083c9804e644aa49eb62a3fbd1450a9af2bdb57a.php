<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Tambah Data Penjualan</div>
                <div class="card-body">

                    <?php echo $__env->make('layouts.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('layouts.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <!---->

                    <form action='/admin/penjualan' method='POST' enctype='multipart/form-data'>
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="id_pelanggan">id_pelanggan*</label>
                            <select class="form-control <?php echo e($errors->has('id_pelanggan') ? 'is-invalid': ''); ?>" name="id_pelanggan" placeholder="id_pelanggan" required>

                            <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <?php if($errors->has('id_pelanggan')): ?>
                            <p class="text-danger"><?php echo e($errors->first('id_pelanggan')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="id_barang">id_barang*</label>
                            <select class="form-control <?php echo e($errors->has('id_barang') ? 'is-invalid': ''); ?>" name="id_barang" placeholder="id_barang" required>

                            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <?php if($errors->has('id_barang')): ?>
                            <p class="text-danger"><?php echo e($errors->first('id_barang')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="jumlah">jumlah*</label>
                            <input class="form-control" type="number" name="jumlah" placeholder="jumlah">
                            <?php if($errors->has('jumlah')): ?>
                            <p class="text-danger"><?php echo e($errors->first('jumlah')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="harga_jual">harga_jual*</label>
                            <input class="form-control" type="number" name="harga_jual" placeholder="harga_jual">
                            <?php if($errors->has('harga_jual')): ?>
                            <p class="text-danger"><?php echo e($errors->first('harga_jual')); ?></p>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-sm">
                            Simpan data penjualan
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm"
                                onclick='
                                    if(!confirm("Apakah anda yakin akan mereset data ini?"))
                                    {
                                        return false;
                                    }
                                '
                        >
                            Reset
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>