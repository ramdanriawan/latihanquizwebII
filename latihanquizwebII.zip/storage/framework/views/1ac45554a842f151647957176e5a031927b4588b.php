<?php if(session()->has('success')): ?>
<script>
        swal({
          position: 'center',
          type: 'success',
          title: "<?php echo e(session()->get('success')); ?>",
          showConfirmButton: false,
          timer: 1500
        });
</script>

<?php endif; ?>
