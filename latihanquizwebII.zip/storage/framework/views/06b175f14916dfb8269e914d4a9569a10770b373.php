<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Tambah Data Pembelian</div>
                <div class="card-body">

                    <?php echo $__env->make('layouts.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('layouts.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <!---->

                    <form action='/admin/pembelian' method='POST' enctype='multipart/form-data'>
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="barang_id">barang_id*</label>
                            <select class="form-control <?php echo e($errors->has('barang_id') ? 'is-invalid': ''); ?>" name="barang_id" placeholder="nama" required>

                            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <?php if($errors->has('barang_id')): ?>
                            <p class="text-danger"><?php echo e($errors->first('barang_id')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="nama_pemasok">nama_pemasok*</label>
                            <input class="form-control" type="text" name="nama_pemasok" value="<?php echo e(old('nama_pemasok')); ?>" placeholder="nama_pemasok" required>
                            <?php if($errors->has('nama_pemasok')): ?>
                            <p class="text-danger"><?php echo e($errors->first('nama_pemasok')); ?></p>
                            <?php endif; ?>
                        </div>


                        <div class="form-group">
                            <label for="jumlah">jumlah*</label>
                            <input class="form-control" type="text" name="jumlah" value="<?php echo e(old('jumlah')); ?>" placeholder="jumlah" required>
                            <?php if($errors->has('jumlah')): ?>
                            <p class="text-danger"><?php echo e($errors->first('jumlah')); ?></p>
                            <?php endif; ?>
                        </div>


                        <div class="form-group">
                            <label for="harga">harga*</label>
                            <input class="form-control" type="text" name="harga" value="<?php echo e(old('harga')); ?>" placeholder="harga" required>
                            <?php if($errors->has('harga')): ?>
                            <p class="text-danger"><?php echo e($errors->first('harga')); ?></p>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-sm">
                            Simpan data pelanggan
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm"
                                onclick='
                                    if(!confirm("Apakah anda yakin akan mereset data ini?"))
                                    {
                                        return false;
                                    }
                                '
                        >
                            Reset
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>