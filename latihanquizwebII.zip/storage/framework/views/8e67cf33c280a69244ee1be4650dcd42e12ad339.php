<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Penjualan Detail Untuk <b><?php echo e($namaPelanggan); ?></b></div>
                <div class="card-body">

                    <?php echo $__env->make('layouts.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('layouts.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    
                    <form class='hidePrint' action="/admin/penjualan/penjualandetail/<?php echo e($penjualanDetailId); ?>/add" method='post' id='penjualanDetailsCreate'>
                        <?php echo e(csrf_field()); ?>

                        <div class='form-group'>
                            <label>Id Barang</label>
                            <select class='form-control' name='barang_id'>
                                <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangId => $barangNama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($barangId); ?>'><?php echo e($barangNama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class='form-group'>
                            <label>Harga Per Item</label>
                            <input type='number' name='harga_per_item' placeholder="Harga Per Item" class='form-control' autocomplete="off" min='0'>
                        </div>
                        <div class='form-group'>
                            <label>Stok</label>
                            <input type='number' name='stok' placeholder="Stok" class='form-control' autocomplete="off" min='0'>
                        </div>
                        <div class='form-group'>
                            <label>Jumlah</label>
                            <input type='number' name='jumlah' placeholder="Jumlah" class='form-control' autocomplete="off" min='0'>
                        </div>
                        <div class='form-group'>
                            <label>Total Harga</label>
                            <input type='number' name='total_harga' placeholder="Total Harga" class='form-control' autocomplete="off"  min='0'>
                        </div>
                        <div class='form-group'>
                            <button class='btn btn-primary' type='submit'>+Add</button>
                            <button class='btn btn-warning' type='reset'>Reset</button>
                        </div>
                    </form>

                    
                    <table class='table' id='penjualanDetailTable'> 
                        <thead>
                            <th>No</th>
                            <th>Nama Barang</th>
                            <th>Jumlah</th>
                            <th>Total</th>
                            <th class="hidePrint">Action</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $penjualanDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjualanDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($penjualanDetail->barang->nama); ?></td>
                                    <td><?php echo e(number_format($penjualanDetail->jumlah, 2, ',', '.')); ?></td>
                                    <td>Rp<?php echo e(number_format($penjualanDetail->total, 2, ',', '.')); ?></td>
                                    <td class="hidePrint">
                                        <span class='btn-group btn-group-sm'>
                                             <form id='formDelete' action='/admin/penjualan/penjualandetail/<?php echo e($penjualanDetail->id); ?>/delete' method='post'>
                                                 <?php echo e(csrf_field()); ?>

                                                 <input type='hidden' name='_method' value='DELETE'>
                                             </form>
                                             <button form='formDelete' class='btn btn-danger btn-sm btn-delete' type='submit' data-nama='<?php echo e($penjualanDetail->id); ?>' data-token='<?php echo e(csrf_token()); ?>'> <i class='far fa-trash-alt float-right'></i>
                                             </button>
                                     </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><h4>Total</h4></td><td></td><td></td><td><h4 class='text-success'>Rp<?php echo e(number_format(collect($penjualanDetails)->sum('total'), 2, ',', '.')); ?></h4></td>
                        </tbody>
                        <tfoot>
                            <tr class="hidePrint">
                                <td></td><td></td><td></td><td colspan='2'><button class="btn btn-info btn-block"><i class='fas fa-print' id='printPenjualanDetail'> Print</i></button></td>
                            </tr>
                        </tfoot>
                    </tabel>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>