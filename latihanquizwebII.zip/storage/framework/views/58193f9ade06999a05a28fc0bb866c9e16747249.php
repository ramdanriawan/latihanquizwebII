<?php if(session()->has('error')): ?>
    <script>
        swal({
          position: 'center',
          type: 'error',
          title: '<?php echo e(session()->get('error')); ?>',
          showConfirmButton: false,
          timer: 1500
        });
</script>
<?php endif; ?>
