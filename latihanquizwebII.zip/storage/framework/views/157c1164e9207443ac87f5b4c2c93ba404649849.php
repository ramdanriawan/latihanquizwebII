<!DOCTYPE html>
<?php
    $dbName = DB::getDatabaseName();
    $tables = DB::select("show tables where `Tables_in_$dbName` not in('users', 'migrations')");
?>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- CSRF Token -->
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>


    <!-- Scripts Bawaan laravel -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('node_modules/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">

    
    <script src="/node_modules/jquery/dist/jquery.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/jquery.dataTables.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/dataTables.jqueryui.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/dataTables.buttons.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/buttons.jqueryui.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/jszip.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/pdfmake.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/vfs_fonts.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/buttons.html5.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/buttons.print.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/buttons.colVis.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/dataTables.select.min.js" charset="utf-8"></script>
    <script src="/node_modules/datatables/dataTables.checkboxes.min.js"></script>

    <link rel="stylesheet" href="/node_modules/datatables/jquery-ui.css">
    <link rel="stylesheet" href="/node_modules/datatables/dataTables.jqueryui.min.css">
    <link rel="stylesheet" href="/node_modules/datatables/buttons.jqueryui.min.css">
    <link rel="stylesheet" href="/node_modules/datatables/select.dataTables.min.css">
    <link type="text/css"  href="/node_modules/datatables/dataTables.checkboxes.css" rel="stylesheet" />

    
    <script src="<?php echo e(asset('node_modules/sweetalert2/dist/sweetalert2.all.min.js')); ?>" charset="utf-8"></script>
    <link rel="stylesheet" href="<?php echo e(asset('node_modules/sweetalert2/dist/sweetalert2.min.css')); ?>">

    
    <script src="<?php echo e(asset('js/accounting.min.js')); ?>" charset="utf-8"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/barang/script.js')); ?>" defer></script>

</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                        <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                Data Master <span class="caret"></span>
                            </a>
                           <div class="dropdown-menu">
                               <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $table = (array) $table;
                                    $table["Tables_in_$dbName"] = substr_replace($table["Tables_in_$dbName"], '', -1);
                                ?>

                               <a class="dropdown-item" href="<?php echo e(url("admin/{$table["Tables_in_$dbName"]}")); ?>">
                                   Data <?php echo e($table["Tables_in_$dbName"]); ?>

                               </a>
                               <a class="dropdown-item" href="<?php echo e(url("admin/{$table["Tables_in_$dbName"]}/create")); ?>">
                                   Tambah  <?php echo e($table["Tables_in_$dbName"]); ?>

                               </a>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                       </li>
                      <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <div class='container'>
            <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>
</body>
</html>
