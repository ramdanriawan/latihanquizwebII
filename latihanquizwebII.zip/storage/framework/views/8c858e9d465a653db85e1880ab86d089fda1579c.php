<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<!DOCTYPE html>
<html>
<head>
    <title>
        Laporan Barang
    </title>
</head>
<body  style="background: white;">
    <div class="container-fluid mt-2">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <center>
                <h3>
                    LAPORAN BARANG <br>
                </h3>
            </center>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Harga Jual</th>
                        <th>Stok</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($row->nama); ?></td>
                        <td><?php echo e(number_format($row->harga_jual,0,'','.')); ?></td>
                        <td><?php echo e($row->stok); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
 
            </table>
        </div>
    </div>
</div>
</body>
</html>
