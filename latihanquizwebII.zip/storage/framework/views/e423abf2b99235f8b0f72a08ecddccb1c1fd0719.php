<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Tambah Data Barang</div>
                <div class="card-body">

                    <?php echo $__env->make('layouts.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('layouts.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <!---->

                    <form action='/admin/barang' method='post' enctype='multipart/form-data'>
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="nama">Nama*</label>
                            <input class="form-control" type="text" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="nama" required>
                            <?php if($errors->has('nama')): ?>
                            <p class="text-danger"><?php echo e($errors->first('nama')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="harga_jual">Harga Jual*</label>
                            <input class="form-control" type="text" name="harga_jual" value="<?php echo e(old('harga_jual')); ?>" placeholder="harga_jual" required>
                            <?php if($errors->has('harga_jual')): ?>
                            <p class="text-danger"><?php echo e($errors->first('harga_jual')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="stok">stok*</label>
                            <input class="form-control" type="text" name="stok" value="<?php echo e(old('stok')); ?>" placeholder="stok" required>
                            <?php if($errors->has('stok')): ?>
                            <p class="text-danger"><?php echo e($errors->first('stok')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="gambar">Gambar (tandai beberapa sekaligus), max:5</label>
                            <input class="form-control  <?php echo e($errors->has('gambar') || $errors->has('gambar.*') ? 'is-invalid': ''); ?>" type="file" name="gambar[]" required multiple>
                            <?php if($errors->has('gambar.*')): ?>
                            <p class="text-danger"><?php echo e($errors->first('gambar.*')); ?></p>
                            <p class="text-danger"><?php echo e($errors->first('gambar')); ?></p>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-sm">
                            Simpan data barang
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm"
                                onclick='
                                    if(!confirm("Apakah anda yakin akan mereset data ini?"))
                                    {
                                        return false;
                                    }
                                '
                        >
                            Reset
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>