<?php $__env->startSection('content'); ?>
        <div class="col-md-9 mt-4">
            <div class="card">
                <div class="card-header">DASHBOARD</div>
                <div class="card-body">
                        SELAMAT DATANG <?php echo e(\Auth::guard('member')->user()->nama); ?>

                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>