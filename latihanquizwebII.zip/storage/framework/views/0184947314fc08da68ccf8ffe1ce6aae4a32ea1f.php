<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>

                <div class="card-header">Data Penjualan</div>

                <div class="card-body">
                   <table class="table table-bordered table-hover">
                       <thead>
                           <tr>
                               <th>No</th>
                               <th>Id Pelanggan</th>
                               <th>Id Barang</th>
                               <th>Jumlah</th>
                               <th>Harga Jual</th>
                               <th>Total Harga</th>
                               <th>Actions</th>
                           </tr>
                       </thead>
                       <tbody>
                         <?php $__currentLoopData = $penjualans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjualan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                               <td><?php echo e($penjualan->id_pelanggan); ?></td>
                               <td><?php echo e($penjualan->id_barang); ?></td>
                               <td><?php echo e($penjualan->jumlah); ?></td>
                               <td><?php echo e($penjualan->harga_jual); ?></td>
                               <td><?php echo e($penjualan->total_harga); ?></td>

                                   <td>
                                    <span class="btn-group btn-group-sm">
                                        <button class="btn btn-primary btn-sm indexBtnEdit" data-id='<?php echo e($penjualan->id); ?>' data-toggle='modal' data-target='#editModal<?php echo e($penjualan->id); ?>'>
                                            <i class="far fa-edit"></i>
                                        </button>
                                        <form id="formDelete" action="/admin/penjualan/<?php echo e($penjualan->id); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="_method" value="DELETE">
                                        </form>
                                        <button form="formDelete" class="btn btn-danger btn-sm btn-delete" type="submit" data-nama="<?php echo e($penjualan->id); ?>" data-token='<?php echo e(csrf_token()); ?>'> <i class="far fa-trash-alt"></i>
                                        </button>
                                    </span>

                               </td>
                           </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                   </table>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<div class="modal fade" id="gambarModal" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
          <h4 class="modal-title">Gambar untuk <span id="dataGambarNama"></span></h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body">
          <div id="demo" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ul class="carousel-indicators">
              <li data-target="#demo" data-slide-to="0" class="active"></li>
              <li data-target="#demo" data-slide-to="1"></li>
              <li data-target="#demo" data-slide-to="2"></li>
            </ul>

            <!-- The slideshow -->
            <div class="carousel-inner" id='gambarItem'>
                
            </div>

            <!-- Left and right controls -->
            <a class="carousel-control-prev" href="#demo" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
              <span class="carousel-control-next-icon"></span>
            </a>

          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php $__currentLoopData = $penjualans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjualan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div id="editModal<?php echo e($penjualan->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-body">
            <div class="card">
            <div class="card-header">Edit data</div>
                <div class="card-body">

                    <?php echo $__env->make('layouts.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('layouts.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <form action='/admin/penjualan/<?php echo e($penjualan->id); ?>' method='post'>
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">

                        <div class="form-group">
                            <label for="id_pelanggan">id_pelanggan*</label>
                            <select class="form-control <?php echo e($errors->has('id_pelanggan') ? 'is-invalid': ''); ?>" name="id_pelanggan" placeholder="id_pelanggan" required>

                            <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($key == $penjualan->id_pelanggan ? ' selected': ''); ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <?php if($errors->has('id_pelanggan')): ?>
                            <p class="text-danger"><?php echo e($errors->first('id_pelanggan')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="id_barang">id_barang*</label>
                            <select class="form-control <?php echo e($errors->has('id_barang') ? 'is-invalid': ''); ?>" name="id_barang" placeholder="id_barang" required>

                            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($key == $penjualan->barang_id ? ' selected': ''); ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <?php if($errors->has('id_barang')): ?>
                            <p class="text-danger"><?php echo e($errors->first('id_barang')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="jumlah">jumlah*</label>
                            <input class="form-control <?php echo e($errors->has('jumlah') ? 'is-invalid': ''); ?>" type="text" name="jumlah" value="<?php echo e($penjualan->jumlah); ?>" placeholder="jumlah" required>
                            <?php if($errors->has('jumlah')): ?>
                            <p class="text-danger"><?php echo e($errors->first('jumlah')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="harga_jual">jumlah*</label>
                            <input class="form-control <?php echo e($errors->has('harga_jual') ? 'is-invalid': ''); ?>" type="text" name="harga_jual" value="<?php echo e($penjualan->harga_jual); ?>" placeholder="harga_jual" required>
                            <?php if($errors->has('harga_jual')): ?>
                            <p class="text-danger"><?php echo e($errors->first('harga_jual')); ?></p>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-sm">
                            Simpan data penjualan
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm"
                                onclick='
                                    if(!confirm("Apakah anda yakin akan mereset data ini?"))
                                    {
                                        return false;
                                    }
                                '
                        >
                            Reset
                        </button>
                    </form>
                </div>
            </div>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>