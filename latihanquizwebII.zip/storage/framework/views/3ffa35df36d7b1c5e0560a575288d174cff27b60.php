<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>

                <div class="card-header">Data <?php echo e($halaman); ?></div>

                <div class="card-body">
                   <table class="table table-bordered table-hover">
                       <thead>
                           <tr>
                               <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <th><?php echo e($column); ?></th>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tr>
                       </thead>
                       <tbody>
                         <?php echo $setTbody; ?>

                       </tbody>
                   </table>
                </div>
                <?php if(method_exists($datas, 'links')): ?>
                        <?php echo e($datas->links()); ?>

                    <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<div class="modal fade" id="gambarModal" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
          <h4 class="modal-title">Gambar untuk <span id="dataGambarNama"></span></h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body">
          <div id="demo" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ul class="carousel-indicators">
              <li data-target="#demo" data-slide-to="0" class="active"></li>
              <li data-target="#demo" data-slide-to="1"></li>
              <li data-target="#demo" data-slide-to="2"></li>
            </ul>

            <!-- The slideshow -->
            <div class="carousel-inner" id='gambarItem'>
                
            </div>

            <!-- Left and right controls -->
            <a class="carousel-control-prev" href="#demo" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
              <span class="carousel-control-next-icon"></span>
            </a>

          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div id="editModal<?php echo e($data->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-body">
            <div class="card">
            <div class="card-header">Edit data</div>
                <div class="card-body">

                    <?php echo $__env->make('layouts.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('layouts.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <form action='/admin/pembelian/<?php echo e($data->id); ?>' method='post'>
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">

                        <div class="form-group">
                            <label for="barang_id">barang_id*</label>
                            <select class="form-control <?php echo e($errors->has('barang_id') ? 'is-invalid': ''); ?>" name="barang_id" placeholder="nama" required>

                            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($key == $data->barang_id ? ' selected': ''); ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <?php if($errors->has('barang_id')): ?>
                            <p class="text-danger"><?php echo e($errors->first('barang_id')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="nama_pemasok">nama_pemasok*</label>
                            <input class="form-control <?php echo e($errors->has('nama_pemasok') ? 'is-invalid': ''); ?>" type="text" name="nama_pemasok" value="<?php echo e($data->nama_pemasok); ?>" placeholder="nama_pemasok" required>
                            <?php if($errors->has('nama_pemasok')): ?>
                            <p class="text-danger"><?php echo e($errors->first('nama_pemasok')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="jumlah">jumlah*</label>
                            <input class="form-control <?php echo e($errors->has('jumlah') ? 'is-invalid': ''); ?>" type="text" name="jumlah" value="<?php echo e($data->jumlah); ?>" placeholder="jumlah" required>
                            <?php if($errors->has('jumlah')): ?>
                            <p class="text-danger"><?php echo e($errors->first('jumlah')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="harga">harga*</label>
                            <input class="form-control <?php echo e($errors->has('harga') ? 'is-invalid': ''); ?>" type="text" name="harga" value="<?php echo e($data->harga); ?>" placeholder="harga" required>
                            <?php if($errors->has('harga')): ?>
                            <p class="text-danger"><?php echo e($errors->first('harga')); ?></p>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-sm">
                            Simpan data pembelian
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm"
                                onclick='
                                    if(!confirm("Apakah anda yakin akan mereset data ini?"))
                                    {
                                        return false;
                                    }
                                '
                        >
                            Reset
                        </button>
                    </form>
                </div>
            </div>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>