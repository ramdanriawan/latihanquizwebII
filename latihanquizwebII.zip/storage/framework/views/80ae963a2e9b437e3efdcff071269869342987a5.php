<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Tambah Data Pelanggan</div>
                <div class="card-body">

                    <?php echo $__env->make('layouts.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('layouts.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <!---->

                    <form action='/admin/pelanggan' method='post' enctype='multipart/form-data'>
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="nama">Nama*</label>
                            <input class="form-control" type="text" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="nama" required>
                            <?php if($errors->has('nama')): ?>
                            <p class="text-danger"><?php echo e($errors->first('nama')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="umur">Umur*</label>
                            <input class="form-control" type="text" name="umur" value="<?php echo e(old('umur')); ?>" placeholder="nama" required>
                            <?php if($errors->has('umur')): ?>
                            <p class="text-danger"><?php echo e($errors->first('umur')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="alamat">alamat*</label>
                            <input class="form-control" type="text" name="alamat" value="<?php echo e(old('alamat')); ?>" placeholder="alamat" required>
                            <?php if($errors->has('alamat')): ?>
                            <p class="text-danger"><?php echo e($errors->first('alamat')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="gambar">Gambar (tandai beberapa sekaligus), max:5</label>
                            <input class="form-control  <?php echo e($errors->has('gambar') || $errors->has('gambar.*') ? 'is-invalid': ''); ?>" type="file" name="gambar[]" required multiple>
                            <?php if($errors->has('gambar.*')): ?>
                            <p class="text-danger"><?php echo e($errors->first('gambar.*')); ?></p>
                            <p class="text-danger"><?php echo e($errors->first('gambar')); ?></p>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-sm">
                            Simpan data pelanggan
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm"
                                onclick='
                                    if(!confirm("Apakah anda yakin akan mereset data ini?"))
                                    {
                                        return false;
                                    }
                                '
                        >
                            Reset
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>