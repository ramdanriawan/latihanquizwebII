<?php

namespace App\Http\Controllers;

use App\PenjualanDetail;
use Illuminate\Http\Request;
use App\Settingan\Settingan;

class PenjualanDetailController extends Controller
{
    public function index()
    {

    }

    public function create()
    {

    }

    public function store(Request $request)
    {

    }

    public function show(PenjualanDetail $penjualanDetail)
    {

    }

    public function edit(PenjualanDetail $penjualanDetail)
    {

    }

    public function update(Request $request, PenjualanDetail $penjualanDetail)
    {

    }

    public function destroy(PenjualanDetail $penjualanDetail)
    {

    }
}
